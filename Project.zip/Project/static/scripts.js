// Add Materials to Inventory
$('#materials-form').on('submit', function(e) {
    e.preventDefault();
    var materials = $('#materials').val();
    
    $.ajax({
        url: '/materials',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ materials: materials }),
        success: function(response) {
            $('#error-message').text('');
            alert('Materials added successfully!');
            $('#materials').val(''); // Clear the input field
        },
        error: function(response) {
            $('#error-message').text(response.responseJSON.error);
        }
    });
});

// Add Formulation to System
$('#formulation-form').on('submit', function(e) {
    e.preventDefault();
    var dosage_form = $('#dosage_form').val();
    var materials = $('#formulation_materials').val();

    $.ajax({
        url: '/formulation',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ dosage_form: dosage_form, materials: materials }),
        success: function(response) {
            $('#success-message').text(response.message);
            $('#formulation_form')[0].reset(); // Reset the form
        },
        error: function(response) {
            alert(response.responseJSON.error);
        }
    });
});

// Load Formulations on Click
$('#load-formulations').on('click', function() {
    $.ajax({
        url: '/formulations',
        type: 'GET',
        success: function(response) {
            $('#formulations-container').empty(); // Clear previous list
            if (response.length > 0) {
                response.forEach(function(formulation) {
                    const formulationItem = `
                        <li>
                            <strong>Dosage Form:</strong> ${formulation.dosage_form} <br>
                            <strong>Materials:</strong> ${JSON.stringify(formulation.materials)}
                        </li>
                    `;
                    $('#formulations-container').append(formulationItem);
                });
                $('#formulations-list').show();
            } else {
                $('#formulations-container').append('<li>No formulations available.</li>');
                $('#formulations-list').show();
            }
        },
        error: function(response) {
            alert('Error fetching formulations.');
        }
    });
});
