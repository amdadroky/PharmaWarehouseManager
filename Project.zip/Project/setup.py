from setuptools import setup
setup( 
    name='Pharma Warehouse Manager',  
    version='1.1.0',  
    description='Pharma Warehouse Manager', 
    author='Amdad Hossain Roky', 
    author_email='hfpy2e@gmail.com', 
    url='headfirstlabs.com', 
    py_modules=['Pharmaw'],
    )
