from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

# Data storage
materials_stock = {}
formulations = []

# File to save formulations
FORMULATION_FILE = "formulations.txt"
if not os.path.exists(FORMULATION_FILE):
    open(FORMULATION_FILE, 'w').close()

# Home route
@app.route('/')
def index():
    return render_template('index.html')

# Add Materials
@app.route('/materials', methods=['POST'])
def add_materials():
    data = request.json
    materials = data.get('materials')  # Expected: "Paracetamol:50, Sugar:20"

    try:
        for material in materials.split(','):
            name, quantity = material.split(':')
            name = name.strip()
            quantity = float(quantity.strip())
            materials_stock[name] = materials_stock.get(name, 0) + quantity

        return jsonify({"message": "Materials added successfully.", "stock": materials_stock})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Get Materials
@app.route('/materials', methods=['GET'])
def get_materials():
    return jsonify(materials_stock)

# Add Formulation
@app.route('/formulation', methods=['POST'])
def add_formulation():
    data = request.json
    dosage_form = data.get('dosage_form')
    materials = data.get('materials')

    try:
        materials_dict = {}
        for material in materials.split(','):
            name, quantity = material.split(':')
            materials_dict[name.strip()] = float(quantity.strip())

        formulation = {'dosage_form': dosage_form, 'materials': materials_dict}
        formulations.append(formulation)

        with open(FORMULATION_FILE, 'a') as file:
            file.write(f"{dosage_form}: {materials_dict}\n")

        return jsonify({"message": "Formulation added successfully.", "formulations": formulations})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Produce Batches
@app.route('/produce', methods=['POST'])
def produce_batches():
    data = request.json
    batch_materials = data.get('batch_requirements')

    try:
        batch_dict = {}
        for material in batch_materials.split(','):
            name, quantity = material.split(':')
            batch_dict[name.strip()] = float(quantity.strip())

        # Check against formulation minimum requirements
        for formulation in formulations:
            required_materials = formulation['materials']
            for material, required_quantity in required_materials.items():
                if material not in batch_dict or batch_dict[material] < required_quantity:
                    return jsonify({
                        "error": f"Material '{material}' is less than the formulation requirement ({required_quantity})."
                    }), 400
                if batch_dict[material] > required_quantity:
                    return jsonify({
                        "warning": f"Material '{material}' exceeds the minimum requirement ({required_quantity}). Please remove extra materials."
                    }), 400

        # Calculate possible batches
        possible_batches = float('inf')
        for material, required_quantity in batch_dict.items():
            if materials_stock.get(material, 0) < required_quantity:
                return jsonify({"error": f"Not enough {material} available for production."}), 400

            possible_batches = min(possible_batches, materials_stock[material] // required_quantity)

        if possible_batches < 1:
            return jsonify({"error": "Insufficient materials to produce even one batch."}), 400

        # Deduct material stock
        for material, required_quantity in batch_dict.items():
            materials_stock[material] -= required_quantity * possible_batches

        return jsonify({"message": f"Successfully produced {int(possible_batches)} batch(es).",
                        "remaining_stock": materials_stock})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
